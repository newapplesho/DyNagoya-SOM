Pharo-1.4-one-click 1.0

- Mac: launch Pharo-1.4-one-click.app
- Linux: launch Pharo-1.4-one-click.sh
- Windows: launch Pharo-1.4-one-click.bat

This distribution was built July 19, 2012.
